<?php
$type = "riskproject";
include dirname(__FILE__).'/qrm-type-template.php';
